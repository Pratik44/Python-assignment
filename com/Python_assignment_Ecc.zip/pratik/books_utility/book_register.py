import csv 

class Book_register:

    def set_heading():
        header = ['ID', "_TITLE", "NO_PAGES", "PRICE"]

        with open("C:\Users\pratik.deenbandhu\Documents\SRE training\PythonAssignment\com\pratik\books_utility\book_register.csv", 'a') as newFile:
            newFileWriter = csv.writer(newFile)
            newFileWriter.writerows(header)

        newFile.close()

        with open("C:\Users\pratik.deenbandhu\Documents\SRE training\PythonAssignment\com\pratik\books_utility\book_registry.csv",'r') as readfile:
            newFileReader = csv.reader(readfile)
            for row in newFileReader:
                print(row)


entry_header = Book_register()
Book_register.set_heading()